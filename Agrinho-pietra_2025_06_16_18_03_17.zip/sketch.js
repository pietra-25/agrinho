let tree;
let raindrops = [];
let maxRaindrops = 100;
let treeGrowthFactor = 0.01; // Ajuste para controlar a velocidade de crescimento da árvore
let branchProbability = 0.8;

function setup() {
  createCanvas(800, 600);
  tree = new Tree(width / 2, height);
  for (let i = 0; i < maxRaindrops; i++) {
    raindrops.push(new Raindrop());
  }
}

function draw() {
  background(135, 206, 235); // Céu azul claro
  fill(139, 69, 19); // Chão marrom
  noStroke();
  rect(0, height * 0.9, width, height * 0.1);

  for (let i = 0; i < raindrops.length; i++) {
    raindrops[i].fall();
    raindrops[i].display();
  }

  push();
  translate(tree.x, tree.y);
  tree.grow();
  tree.display();
  pop();
}

// --- Classe para a Árvore ---
class Tree {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.baseLength = 50;
    this.maxDepth = 4; // Profundidade inicial
  }

  grow() {
    this.baseLength += treeGrowthFactor;
    if (this.baseLength > 200) { // Limite de crescimento aumentado para ser mais alta
      this.baseLength = 200;
    }
    // Aumenta a profundidade da árvore mais rapidamente e para um limite maior
    if (this.maxDepth < 10 && frameCount % 50 === 0) {
      this.maxDepth++;
    }
  }

  display() {
    stroke(100, 70, 40);
    strokeWeight(this.baseLength / 10);
    this.drawBranch(0, -this.baseLength, this.baseLength, this.maxDepth);
  }

  drawBranch(x1, y1, len, depth) {
    if (depth === 0) {
      return;
    }

    let x2 = x1;
    let y2 = y1 - len;

    let branchColorR = map(depth, this.maxDepth, 0, 80, 50);
    let branchColorG = map(depth, this.maxDepth, 0, 150, 200);
    let branchColorB = map(depth, this.maxDepth, 0, 50, 100);
    stroke(branchColorR, branchColorG, branchColorB);
    strokeWeight(len / 15);

    line(x1, y1, x2, y2);

    push();
    translate(x2, y2);

    // Folhas são desenhadas na ponta dos galhos
    if (depth <= 3) {
      noStroke();
      fill(50 + random(-10, 10), 180 + random(-10, 10), 50 + random(-10, 10), 200);
      let leafSize = map(len, 0, this.baseLength, 5, 20);
      for (let i = 0; i < 4; i++) {
        let angleOffset = random(-PI / 6, PI / 6);
        let distanceOffset = random(0, 8);
        push();
        rotate(angleOffset);
        ellipse(distanceOffset, -leafSize / 2, leafSize, leafSize * 1.5);
        pop();
      }
    }

    // Primeiro sub-galho (esquerda) - MUITO MENOS aleatoriedade no ângulo
    if (random(1) < branchProbability) {
      push();
      rotate(PI / 6 + random(-PI / 60, PI / 60)); // <-- Valor reduzido!
      this.drawBranch(0, 0, len * 0.7, depth - 1);
      pop();
    }

    // Segundo sub-galho (direita) - MUITO MENOS aleatoriedade no ângulo
    if (random(1) < branchProbability) {
      push();
      rotate(-PI / 6 + random(-PI / 60, PI / 60)); // <-- Valor reduzido!
      this.drawBranch(0, 0, len * 0.7, depth - 1);
      pop();
    }

    pop();
  }
}

// --- Classe para a Gota de Chuva ---
class Raindrop {
  constructor() {
    this.x = random(width);
    this.y = random(-height, 0);
    this.z = random(0, 20);
    this.len = map(this.z, 0, 20, 10, 20);
    this.speed = map(this.z, 0, 20, 4, 10);
  }

  fall() {
    this.y += this.speed;
    if (this.y > height * 0.9) {
      this.y = random(-200, -10);
      this.x = random(width);
    }
  }

  display() {
    stroke(100, 150, 255, 180);
    strokeWeight(map(this.z, 0, 20, 1, 3));
    line(this.x, this.y, this.x, this.y + this.len);
  }
}






















